const gameModeButtons = document.querySelectorAll('.game-mode-button');

// Handle the click events for game mode buttons
gameModeButtons.forEach((button) => {
  button.addEventListener('click', (event) => {
    const gameMode = event.target.parentElement.id;
    // Implement specific actions based on the game mode
    switch (gameMode) {
      case 'adventure':
        startAdventureGame();
        break;
      case 'strategy':
        startStrategyGame();
        break;
      case 'puzzle':
        startPuzzleGame();
        break;
      case 'challenge':
        startChallengeGame();
        break;
      default:
        console.error('Unknown game mode:', gameMode);
    }
  });
});

// Implement actions for each game

function loadAdventureLevel(level) {
    // Create the game level environment and display the level objectives
    const levelContainer = document.createElement('div');
    levelContainer.id = 'adventure-level-' + level;
    document.getElementById('adventure-game').appendChild(levelContainer);
  
    const levelObjectives = document.createElement('p');
    levelObjectives.textContent = 'Level ' + level + ' Objectives:';
    // Add specific objectives for each level
    switch (level) {
      case 1:
        levelObjectives.textContent += 'Clean up the polluted river by collecting water purification items.';
        break;
      case 2:
        levelObjectives.textContent += 'Restore the forest by planting trees and protecting them from pests.';
        break;
      case 3:
        levelObjectives.textContent += 'Protect the endangered wildlife from poachers and promote sustainable ecotourism.';
        break;
    }
    levelContainer.appendChild(levelObjectives);
  
    // Create a map of the game level with interactive elements
    const levelMap = new Map();
  
    // Add obstacles, collectibles, and interactive objects to the map
    switch (level) {
      case 1:
        levelMap.set('polluted-river', {
            type: 'obstacle',
            interaction: () => {
              alert('The river is polluted and needs to be cleaned up. Collect water purification items to restore the river.');
            }
          });
          
  
          levelMap.set('water-purification-item', {
            type: 'collectible',
            interaction: () => {
              alert('You found a water purification item! Collect more to clean up the river.');
              levelMap.delete('water-purification-item');
              document.getElementById('water-purification-item').remove();
              checkProgress();
            }
          });
          
  
      case 2:
        levelMap.set('deforested-area', {
            type: 'obstacle',
            interaction: () => {
              alert('The forest has been devastated by deforestation. Plant trees to restore the ecosystem.');
            }
          });
          
  
          levelMap.set('sapling', {
            type: 'collectible',
            interaction: () => {
              alert('You planted a sapling! Plant more to reforest the area.');
              levelMap.delete('sapling');
              document.getElementById('sapling').remove();
              checkProgress();
            }
          });
          
        break;
  
      case 3:
        levelMap.set('endangered-animal', {
            type: 'interactive-object',
            interaction: () => {
              alert('You encountered an endangered animal! Protect it from poachers and promote sustainable ecotourism.');
            }
          });
          
  
          levelMap.set('poacher-trap', {
            type: 'obstacle',
            interaction: () => {
              alert('You found a poacher trap! Disarm it to protect the endangered animals.');
            }
          });
          
        break;
        levelMap.set('disarmed-trap', {
            type: 'collectible',
            interaction: () => {
              alert('You disarmed a poacher trap! Continue finding more to protect the animals.');
              levelMap.delete('poacher-trap');
              document.getElementById('poacher-trap').remove();
              checkProgress();
            }
          });
          
    }
  
    // Display the level map and player character
    const mapDisplay = document.createElement('div');
    mapDisplay.id = 'level-map';
    levelContainer.appendChild(mapDisplay);
  
    const playerCharacter = document.createElement('div');
    playerCharacter.id = 'player-character';
    mapDisplay.appendChild(playerCharacter);
  
    // Handle player movement and interaction with objects
    document.addEventListener('keydown', (event) => {
      const player = document.getElementById('player-character');
      const currentPosition = player.getBoundingClientRect();
  
      switch (event.key) {
        case 'ArrowUp':
          player.style.top = parseInt(currentPosition.top) - 50 + 'px';
          checkInteractions(player, levelMap);
          break;
        case 'ArrowDown':
          player.style.top = parseInt(currentPosition.top) + 50 + 'px';
          checkInteractions(player, levelMap);
          break;
        case 'ArrowLeft':
          player.style.left = parseInt(currentPosition.left) - 50 + 'px';
          checkInteractions(player, levelMap);
          break;
        case 'ArrowRight':
          player.style.left = parseInt(currentPosition.left) + 50 + 'px';
          checkInteractions(player, levelMap);
          break;
      }
    });
  
    // Function to check for interactions between player and objects in the map
    function checkInteractions(player, levelMap) {
        const playerPosition = player.getBoundingClientRect();
      
        for (const [objectKey, objectData] of levelMap.entries()) {
          const objectPosition = document.getElementById(objectKey).getBoundingClientRect();
      
          if (isOverlapping(playerPosition, objectPosition)) {
            switch (objectData.type) {
              case 'obstacle':
                objectData.interaction();
                break;
              case 'collectible':
                objectData.interaction();
                levelMap.delete(objectKey);
                document.getElementById(objectKey).remove();
                checkProgress();
                break;
              case 'interactive-object':
                objectData.interaction();
                break;
            }
          }
        }
      }
      
      function isOverlapping(playerRect, objectRect) {
        return (
          playerRect.left < objectRect.right &&
          playerRect.right > objectRect.left &&
          playerRect.top < objectRect.bottom &&
          playerRect.bottom > objectRect.top
        );
      }
      
      function checkProgress() {
        // Check if all level objectives have been completed
        const levelObjectiveCount = document.getElementById('level-objectives').children.length;
        const completedObjectives = levelMap.size === 0;
      
        if (completedObjectives) {
          // Display a message indicating level completion and proceed to the next level
          const levelCompletionMessage = document.createElement('p');
          levelCompletionMessage.textContent = 'Level completed! Proceeding to the next level.';
          document.getElementById('adventure-game').appendChild(levelCompletionMessage);
      
          setTimeout(() => {
            loadAdventureLevel(level + 1);
          }, 2000);
        }
      }
      
      
  
  alert('Starting Adventure Game');
  console.log('Adventure Game started');
}

function startStrategyGame() {
  // Code to start the Strategy game
  alert('Starting Strategy Game');
  console.log('Strategy Game started');
}

function startPuzzleGame() {
  // Code to start the Puzzle game
  alert('Starting Puzzle Game');
  console.log('Puzzle Game started');
}

function startChallengeGame() {
  // Code to start the Challenge game
  alert('Starting Challenge Game');
  console.log('Challenge Game started');
}

